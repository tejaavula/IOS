 import UIKit
 
 var i=9
 var j=10
 var sum = i+j
 print(sum)

 
 var a=10
 var b=56
 var product=0
 var p=a*b
print(p)

 
