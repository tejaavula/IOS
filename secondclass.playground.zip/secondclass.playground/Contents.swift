import UIKit

var a = 10;
var b = 20;
var sum=0;
sum=a+b
print(sum)
//string interpolation
print("The sum is equal to : \(sum)")
//teriminator
print("The sum is ",terminator: "=")
print(sum)
//separator
print(1,2,3)
print(1,2,3,separator: "*")

var fName="Tejaswi"
var lName="Avula"
//Tejaswi Avula
print(fName,lName)
//Tejaswi, Avula
print(fName,lName,separator: ", ")

var str1  = "Bobby"
var str2 = "Bearcat"
var str3 = "-"
print(str1, "-" ,str2) //there is a space here
print(str1,str3,str2)

//constants (let) and variables(var)
var radius = 2.0
var Pi = 3.14
var perimeter = 2*Pi*radius
print("The perimeter of the circle is : \(perimeter)")

var p = 9.0
let q = 2.0
p = p-q
//q = p-q //as it is a constant wee cannot change the value
print(q)
print(p)

//tuples
var httpError = (errorCode:404,errMessage:"Page not found")
print(httpError)
print(httpError.errorCode, terminator: "-")
print(httpError.errMessage)

var name = ("Tejaswi","Avula")
var fname = name.0
var lname = name.1
print(fname,lname)


//1
print("Hii",10,12.25)
var programmingLanguage = "Swift"
print("My favorite programming language is \(programmingLanguage)")
var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")
print("""
Hello
World!
""")
print ("Hello All,\rWelcome to Swift programming")
let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")
print("Welcome to Swift Programming")
print("Fall 2021")
print("************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
//Tuples
var httpError1  = (errorCode : 404  , errorMessage  : "Page Not Found")
print(httpError1)
print(httpError1.errorCode , terminator : ": ")
print(httpError1.errorMessage )


var name1 = ("John","Smith")
var fName1 = name1.0
var lName1 = name1.1
print(fName1 , terminator : ",")
print(lName1)

var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name : "Maryville" , population : 11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname2 = "Joe"
var lname2 = "Root"
(fname2 , lname2) = (lname2 , fname2)
print("First Name is \(fname2) and Last Name is \(lname2)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)

//constants
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14
print(pi)

var age1 : Int = 23
age1 = age1 * 2
print(age1)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

 print(10,20,30)
    print(12.5,15.5)


print ("Hello All,\rWelcome to Swift programming")

let  welcomeMessage1 : String = "Hello!"
   print(welcomeMessage1 , "All")


print("Welcome to Swift Programming")
print("Fall 2021")
print("************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
